import { user } from './user';
export const users:user[] = [
    {
        name: "Charanrajh",
        accountNumber: 15341
    },
    {
        name: "Vamsi",
        accountNumber: 15342
    },{
        name: "Ashish",
        accountNumber: 15343
    },{
        name: "Sathvik",
        accountNumber: 15344
    },{
        name: "Kumar",
        accountNumber: 15345
    },{
        name: "Shabnam",
        accountNumber: 15346
    },

]