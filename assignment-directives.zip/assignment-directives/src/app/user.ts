export interface user {
    name:string,
    accountNumber:number
}