import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  ngOnInit(): void {
  }
  imageURL:string;
  selectedLevel:any;

  data:Array<Object> = [
    {id: 1, name: "select"},
    {id: 2, name: "tiger"},
    {id: 3, name: "lion"},
    {id: 4, name: "elephant"},
    {id: 5, name: "dog"}
  ];

  selected(event:any) {
    this.selectedLevel = event.target.value;
    this.imageURL = "../../assets/images/"+this.selectedLevel+".jpg";
    console.log(this.imageURL);
  }

}
