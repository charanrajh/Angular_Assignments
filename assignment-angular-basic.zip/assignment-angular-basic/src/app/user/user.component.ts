import { Component, OnInit } from '@angular/core';
import { users } from '../mock-users';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  username:string = "User";
  mockUsers:string[] = users;
  ngOnInit(): void {
  }

  onKey(event:KeyboardEvent): void {
    this.username = (event.target as HTMLInputElement).value;
  }

  saveUser(userInput:string):void {
    this.mockUsers.push(userInput);  
  }

}
